package com.example.basicgithubclone.others

object Constants {
    const val API_KEY = "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"
    const val BASE_URL = "https://api.github.com/"
}