package com.example.basicgithubclone

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HiltAndroid  : Application() {
}